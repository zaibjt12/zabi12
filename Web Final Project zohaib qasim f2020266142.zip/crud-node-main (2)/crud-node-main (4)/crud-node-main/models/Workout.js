const mongoose = require("mongoose");

const workoutSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },

  description: {
    type: String,
    required: true,
  },

  author: {
    type: String,
  },

  image: {
    type: String,
  },
  createdDate: {
    type: Date,
  },
  
  category: {
    type: String,
  },
});

const Workout = mongoose.model("Workout", workoutSchema);

module.exports = Workout;
