const express = require("express");
const mongoose = require("mongoose");
const methodOverride = require("method-override");
const Workout = require("./models/Workout");
const app = express();

//connect to mongoDB
mongoose
  .connect("mongodb://0.0.0.0:27017/recepieV2")
  .then(() => {
    console.log(`Connected to MongoDB`);
  })
  .catch((err) => {
    console.log(`Oh No ERROR!`);
    console.log(err);
  });

app.use(methodOverride("_method"));

//parsing data form req.body
app.use(express.urlencoded({ extended: true }));

//static assets
app.use(express.static("public"));

//templating engine
app.set("view engine", "ejs");

//fake database call to get recepie data

//home route
app.get("/",  async (req, res) => {
  try {
    const workouts = await Workout.find().sort([['_id', -1]]);
    // console.log(workout);
    res.render("home", { workouts });
  } catch (error) {
    console.log(`Oh No ERROR!`);
    res.send(error.message);
  }

  // res.render("home");
});


//show fitness page
app.get("/fitness", async (req, res) => {
  try {
    const workouts = await Workout.find();
    res.render("workouts/fit", { workouts });
  } catch (error) {
    console.log(`Oh No ERROR!`);
    res.send(error.message);
  }
});

//render create new fitness page
app.get("/workout/new", (req, res) => {
  res.render("workouts/new");
});

//create new workouts
app.post("/workouts", async (req, res) => {
  const {title,description,author,image,createdDate,category} = req.body;

  const workout = new Workout({
    title,
    description,
    author,
    image,
    createdDate,
    category,
  });
  try {
    await workout.save();
    res.redirect("/fitness");
  } catch (error) {
    console.log(`Oh No ERROR!`);
    res.send(error.message);
  }
});

//show details page
app.get("/workouts/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const foundWorkout = await Workout.findById(id);

    res.render("workouts/workout", { foundWorkout });
  } catch (error) {
    console.log(`Oh No ERROR!`);
    res.send(error.message);
  }
});

//search fitness with category 
app.get("/search", async (req, res) => {

  try {
    const search= req.query.search;
    console.log('searching .................');
    console.log(search);

    const foundWorkout = await Workout.find(({category:(search)}));
    console.log(foundWorkout);

    res.render("workouts/searching", {foundWorkout});
  } catch (error) {
    console.log(`Oh No ERROR!`);
    res.send(error.message);
  }
});




//edit workouts form
app.get("/workouts/:id/edit", async (req, res) => {
  const id = req.params.id;
  const foundWorkout = await Workout.findById(id);
  res.render("workouts/update", { foundWorkout });
});

//update route
app.patch("/workouts/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const foundWorkout = await Recepie.findByIdAndUpdate(id, req.body, {
      new: true,
    });
    console.log(foundWorkout);
    res.redirect("/workouts");
  } catch (error) {
    console.log(`Oh No ERROR!`);
    res.send(error.message);
  }
});

//Delete recepie
app.delete("/workouts/:id", async (req, res) => {
  try {
    await Workout.findByIdAndDelete(req.params.id);
    res.redirect("/fitness");
  } catch (error) {
    console.log(`Oh No ERROR!`);
    res.send(error.message);
  }
});

app.listen(8080, () => {
  console.log("Server Listening at PORT 8080");
});
